package example4;

import java.util.Scanner;

/**
 *
 * @author alumne
 */
public class Example4 {
   public static void main(String[] args) {
     int numero, ciclo=0, suma=0, contador = 0, min=0, max=0,valor=0, i=0, repeticiones=0, repeticiones1=0;
        //fer us d'una col·lecció
        int vect[]=new int[100];
        int vectrep[]=new int [100];
        
        Scanner teclado = new Scanner (System.in);
        
        
        /*System.out.print(numero);*/
       
        while (ciclo ==0) {
            //separa el màxim el codi per facilitar la seva interpretacio
            System.out.print("Insert number:");
            numero=teclado.nextInt();
            if (numero==-1){
                ciclo=1;
            }
            else{
                vect[contador]=numero;
                
                suma=suma+numero;
                if(contador==0){
                    min=numero;
                    max=numero;
                }
                else{
                    if(numero<min){
                        min=numero;
                    }
                    if(numero>max){
                        max=numero;
                    }
                }
            vect[contador]=numero;
            for(i=0;i<=contador;i++){
                if(vect[contador]==vect[contador]){
                    repeticiones++;
                    vectrep[contador]=repeticiones;
                    valor=contador;
                }
            }
            contador++;
            }
        }
        
        System.out.println("Suma:" + suma);
        System.out.println("Mínimo:" + min);
        System.out.println("Máximo:" + max);
        System.out.println("Valor más repetido:" + valor + "se repite: " + repeticiones + "veces");
    }  
   } 

