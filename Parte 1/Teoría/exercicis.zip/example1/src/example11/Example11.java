/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example11;

import java.util.Scanner;

/**
 *
 * @author alumne
 */
public class Example11 {
   public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int number_secret = 15;
        int number;
        int attempts = 4;
        
        System.out.println("Introduce a number");
        number = sc.nextInt();
        if (number == number_secret && attempts < 5) System.out.println("The number is correct");
        while (number != number_secret && attempts >= 1) {
            attempts--;
            if (number_secret > number) {
                System.out.println("The number introduced is smaller");
            } else if (number_secret < number) {
                System.out.println("The number introduced is bigger");
            }
            System.out.println("Try another number: ");

            number = sc.nextInt();

            if (number == number_secret && attempts < 4) {
                System.out.println("Correct. You've done it");
            } else if (number != number_secret && attempts == 0) {
                System.out.println("You don't have any attemps. You lost");
            }
        }

    } 
}
