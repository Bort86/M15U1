package dnaexercise;

import java.io.*;
import java.util.Scanner;

public class ReadFIle {
    public static void readFile(String archivo) throws FileNotFoundException, IOException {
        String file="/home/abde/Escritorio/dna.txt";
        String cadena;
        FileReader f = new FileReader(archivo);
        BufferedReader b = new BufferedReader(f);
        while((cadena = b.readLine())!=null) {
            System.out.println(cadena);
        }
        b.close();
    }

}


