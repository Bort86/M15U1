package dnaexercise;

public class Functions {

    /**
     * Funcion que ingresa una cadena de aminoacidos y me la imprime de atras
     * hacia adelante
     *
     * @param cadena
     */
    public static void reverse(String cadena) {

        String cadena_invertida = "";

        for (int i = cadena.length() - 1; i > 0; i--) {

            cadena_invertida = cadena_invertida + cadena.charAt(i);
        }
        System.out.println("Cadena invertida: "+ cadena_invertida);
    }

    /**
     * Funcion que entra por parametro la cadena de dna y me cuenta la base mas repetida 
     * @param Cadena 
     */
    
    public static void baseMasRepetida(String Cadena) {

        char[] letras;
        int mayorRepeticion = 0;
        char letraMasRepetida = 0;

        letras = Cadena.toCharArray();

        for (int i = 0; i < letras.length; i++) {
            char letraActual = letras[i];
            int contador = 0;

            for (int j = 0; j < letras.length; j++) {
                if (letras[j] == letraActual) {
                    contador++;
                }
            }
            if (mayorRepeticion < contador) {
                mayorRepeticion = contador;
                letraMasRepetida = letraActual;
            }
        }
        System.out.println(letraMasRepetida + " Es la base mas repetida, se repite " + mayorRepeticion + " veces");
    }

    /**
     * Funcion que entra por parametro la cadena de dna y me cuenta la base menos repetida
     * @param Cadena
     */
    public static void baseMenosRepetida(String Cadena) {

        char[] letras;
        int menorRepeticion = 0;
        char letraMenosRepetida=0;

        letras = Cadena.toCharArray();

        for (int i = 0; i < letras.length; i++) {
            char letraActual = letras[i];
            int contador = 0;

            for (int j = 0; j < letras.length; j++) {
                if (letras[j] == letraActual) {
                    contador++;
                }
            }
            if (menorRepeticion > contador) {
                menorRepeticion = contador;
                letraMenosRepetida = letraActual;
            }
        }
        System.out.println(letraMenosRepetida + " Es la base menos repetida, se repite " + menorRepeticion + " veces");
    }

    /**
     * Funcion que entra por parametro la cadena de dna y me cuenta las bases
     * @param cadena
     */
    public static void contarBases(String cadena){
        char[] letras;
        letras = cadena.toCharArray();
        int repeticions=letras.length;
        System.out.println(repeticions);

    }

}
