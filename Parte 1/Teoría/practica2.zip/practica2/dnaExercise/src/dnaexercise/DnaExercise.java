/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dnaexercise;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author ander
 */
public class DnaExercise {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);

        String file="E:\\Anderson\\PROVENÇANA\\DAWBIO2\\M15_JAVA\\PRACTICAS\\practica2\\practica2\\dnaExercise\\DNA.txt";
        String cadena;
        FileReader f = new FileReader(file);
        BufferedReader b = new BufferedReader(f);
        cadena = b.readLine();

        System.out.println("1. Dar la vuelta\n" +
                "2. Contar base más repetida\n" +
                "3. Contar base menos repetida\n" +
                "4. Contar bases\n" +
                "5. Salir");

        int opcion = sc.nextInt();
        switch (opcion) {
            case 1:
                Functions.reverse(cadena);
                break;
            case 2:
                Functions.baseMasRepetida(cadena);
                break;
            case 3:
                Functions.baseMenosRepetida(cadena);
                break;
            case 4:
                Functions.contarBases(cadena);
                break;
            case 5:
                break;
        }
    }

}
